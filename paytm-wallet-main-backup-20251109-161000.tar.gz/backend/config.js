const JWT_SECRET = "rajsecret";

module.exports = JWT_SECRET;